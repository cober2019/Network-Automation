import ipaddress
from socket import gaierror
from ncclient import manager
import xmltodict
import collections
import re